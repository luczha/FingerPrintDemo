﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Plugin.Fingerprint;
namespace App7
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();

            CheckFaceIDAsync();

        }

        async void CheckFaceIDAsync()
        {
            var result = await CrossFingerprint.Current.AuthenticateAsync("Prove you have fingers!");
            if (result.Authenticated)
            {
                // do secret stuff :)
                Console.WriteLine("111111");
            }
            else
            {
                // not allowed to do secret stuff :(
                Console.WriteLine("222222");
            }
        }

    }
}
